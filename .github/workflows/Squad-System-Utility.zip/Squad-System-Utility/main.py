import customtkinter as ctk
import shlex
import subprocess
import threading
import os
import webbrowser
import hashlib
import json
import html
import http.server
import urllib.parse
import secrets
import platform
import time
import stat
import re
import bcrypt
import requests
from datetime import datetime
from PIL import Image

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

ACCENT_COLOR = "#0096D6"
ACCENT_HOVER = "#007AB8"
ACCENT_LIGHT = "#E8F4FD"
BG_DARK = "#F0F2F5"
BG_CARD = "#FFFFFF"
BG_CARD_HOVER = "#F5F7FA"
BG_INPUT = "#F0F2F5"
BG_SIDEBAR = "#F0F2F5"
TEXT_COLOR = "#1F2328"
TEXT_SECONDARY = "#656D76"
TEXT_MUTED = "#8C959F"
SUCCESS_COLOR = "#1A7F37"
ERROR_COLOR = "#CF222E"
WARNING_COLOR = "#9A6700"
BORDER_COLOR = "#D0D7DE"
GOOGLE_RED = "#EA4335"
GOOGLE_BLUE = "#4285F4"

DB_FILE = "users.json"

VALID_AUTH_KEYS = os.environ.get("SQUAD_AUTH_KEYS", "SQUAD-PRO-2024,SQUAD-PREMIUM-2024,SQUAD-ULTIMATE-2024,GREEK-SQUAD-KEY").split(",")

GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")
CURRENT_VERSION = "1.0"
VERSION_URL = "https://www.greeksquadusa.com/version.txt"

GOOGLE_REDIRECT_URI = "http://localhost:8765/callback"
GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo"

MAX_LOGIN_ATTEMPTS = 5
LOGIN_LOCKOUT_SECONDS = 300
_login_attempts = {}


def load_users():
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r") as f:
            return json.load(f)
    return {}


def save_users(users):
    fd = os.open(DB_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(users, f, indent=2)
    try:
        os.chmod(DB_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def hash_password(password):
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(password, hashed):
    if hashed.startswith("$2"):
        return bcrypt.checkpw(password.encode(), hashed.encode())
    return hashlib.sha256(password.encode()).hexdigest() == hashed


def _sanitize_input(text, max_length=128):
    text = text.strip()[:max_length]
    return re.sub(r'[<>&"\']', '', text)


def _check_rate_limit(username):
    now = time.time()
    if username in _login_attempts:
        attempts, first_attempt = _login_attempts[username]
        if now - first_attempt > LOGIN_LOCKOUT_SECONDS:
            _login_attempts[username] = (0, now)
            return True
        if attempts >= MAX_LOGIN_ATTEMPTS:
            remaining = int(LOGIN_LOCKOUT_SECONDS - (now - first_attempt))
            return remaining
    return True


def _record_failed_login(username):
    now = time.time()
    if username in _login_attempts:
        attempts, first_attempt = _login_attempts[username]
        if now - first_attempt > LOGIN_LOCKOUT_SECONDS:
            _login_attempts[username] = (1, now)
        else:
            _login_attempts[username] = (attempts + 1, first_attempt)
    else:
        _login_attempts[username] = (1, now)


def _clear_login_attempts(username):
    _login_attempts.pop(username, None)


def get_hardware_id():
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["wmic", "csproduct", "get", "uuid"],
                capture_output=True, text=True, timeout=10
            )
            lines = [l.strip() for l in result.stdout.strip().split("\n") if l.strip() and l.strip() != "UUID"]
            if lines:
                return lines[0]
        result = subprocess.run(
            ["cat", "/etc/machine-id"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0 and result.stdout.strip():
            mid = result.stdout.strip().upper()
            return f"{mid[:8]}-{mid[8:12]}-{mid[12:16]}-{mid[16:20]}-{mid[20:32]}"
    except Exception:
        pass
    return "UNKNOWN-HWID-0000-0000-000000000000"


class GoogleOAuthHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/callback":
            self.send_response(404)
            self.end_headers()
            return

        params = urllib.parse.parse_qs(parsed.query)

        error = params.get("error", [None])[0]
        if error:
            self.server.auth_code = None
            self.server.auth_error = error
            self._send_html(400, "Authentication Failed", f"Error: {html.escape(error)}. Please try again.")
            self.server.should_stop = True
            return

        returned_state = params.get("state", [None])[0]
        if returned_state != self.server.expected_state:
            self.server.auth_code = None
            self.server.auth_error = "state_mismatch"
            self._send_html(400, "Authentication Failed", "Security validation failed. Please try again.")
            self.server.should_stop = True
            return

        code = params.get("code", [None])[0]
        if code:
            self.server.auth_code = code
            self.server.auth_error = None
            self._send_html(200, "Authentication Successful!", "You can close this window and return to Squad Driver Updater.")
        else:
            self.server.auth_code = None
            self.server.auth_error = "no_code"
            self._send_html(400, "Authentication Failed", "No authorization code received.")
        self.server.should_stop = True

    def _send_html(self, status, title, message):
        color = "#0096D6" if status == 200 else "#CF222E"
        self.send_response(status)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        html = f"""
        <html><body style="background:#F0F2F5;color:#1F2328;font-family:Arial;
        display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
        <div style="text-align:center;background:white;padding:40px 60px;border-radius:12px;
        box-shadow:0 2px 8px rgba(0,0,0,0.1);">
        <h1 style="color:{color}">{title}</h1>
        <p style="color:#656D76">{message}</p>
        </div></body></html>
        """
        self.wfile.write(html.encode())

    def log_message(self, format, *args):
        pass


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Squad Driver Updater")
        self.geometry("1100x750")
        self.minsize(1000, 700)
        self.configure(fg_color=BG_DARK)

        self.current_user = None
        self.google_login_in_progress = False
        self._animation_ids = []

        logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "logo.png")
        self.logo_image_large = ctk.CTkImage(Image.open(logo_path), size=(120, 120))
        self.logo_image_small = ctk.CTkImage(Image.open(logo_path), size=(36, 36))

        self.show_login_screen()

    def _cancel_animations(self):
        for aid in self._animation_ids:
            try:
                self.after_cancel(aid)
            except Exception:
                pass
        self._animation_ids = []

    def clear_window(self):
        self._cancel_animations()
        for widget in self.winfo_children():
            widget.destroy()

    def _fade_in(self, widget, target_alpha=1.0, step=0):
        steps = 12
        if step <= steps:
            alpha = step / steps
            try:
                widget.configure(fg_color=self._blend_color(BG_DARK, BG_CARD, alpha) if hasattr(widget, '_is_card') else None)
            except Exception:
                pass
            aid = self.after(25, self._fade_in, widget, target_alpha, step + 1)
            self._animation_ids.append(aid)

    def _blend_color(self, c1, c2, t):
        r1, g1, b1 = int(c1[1:3], 16), int(c1[3:5], 16), int(c1[5:7], 16)
        r2, g2, b2 = int(c2[1:3], 16), int(c2[3:5], 16), int(c2[5:7], 16)
        r = int(r1 + (r2 - r1) * t)
        g = int(g1 + (g2 - g1) * t)
        b = int(b1 + (b2 - b1) * t)
        return f"#{r:02x}{g:02x}{b:02x}"

    def _slide_in(self, widget, start_y, end_y, step=0):
        steps = 15
        if step <= steps:
            t = step / steps
            ease = t * t * (3 - 2 * t)
            y = start_y + (end_y - start_y) * ease
            try:
                widget.place_configure(rely=y)
            except Exception:
                return
            aid = self.after(20, self._slide_in, widget, start_y, end_y, step + 1)
            self._animation_ids.append(aid)

    def _pulse_widget(self, widget, colors, step=0):
        idx = step % len(colors)
        try:
            widget.configure(fg_color=colors[idx])
        except Exception:
            return
        aid = self.after(800, self._pulse_widget, widget, colors, step + 1)
        self._animation_ids.append(aid)

    def _type_text(self, label, full_text, step=0):
        if step <= len(full_text):
            try:
                label.configure(text=full_text[:step])
            except Exception:
                return
            aid = self.after(40, self._type_text, label, full_text, step + 1)
            self._animation_ids.append(aid)

    def _stagger_appear(self, widgets, delay=80, idx=0):
        if idx < len(widgets):
            try:
                widgets[idx].configure(fg_color=ACCENT_COLOR)
            except Exception:
                return
            aid = self.after(delay, self._stagger_appear, widgets, delay, idx + 1)
            self._animation_ids.append(aid)

    def show_login_screen(self):
        self.clear_window()

        outer = ctk.CTkFrame(self, fg_color=BG_DARK)
        outer.pack(fill="both", expand=True)

        container = ctk.CTkFrame(outer, fg_color="transparent")
        container.place(relx=0.5, rely=0.6, anchor="center")

        self._slide_in(container, 0.6, 0.5)

        ctk.CTkLabel(container, image=self.logo_image_large, text="").pack(pady=(0, 10))

        title_label = ctk.CTkLabel(
            container,
            text="",
            font=ctk.CTkFont(size=30, weight="bold"),
            text_color=TEXT_COLOR,
        )
        title_label.pack(pady=(0, 3))
        self._type_text(title_label, "Squad Driver Updater")

        subtitle = ctk.CTkLabel(
            container,
            text="Professional System Utility Suite",
            font=ctk.CTkFont(size=13),
            text_color=TEXT_SECONDARY,
        )
        subtitle.pack(pady=(0, 25))

        card = ctk.CTkFrame(container, fg_color=BG_CARD, corner_radius=12, border_width=1, border_color=BORDER_COLOR)
        card.pack(padx=20, pady=5)

        inner_card = ctk.CTkFrame(card, fg_color=BG_CARD, corner_radius=12)
        inner_card.pack(padx=25, pady=25)

        self.auth_tab = ctk.CTkTabview(
            inner_card, fg_color=BG_CARD,
            segmented_button_selected_color=ACCENT_COLOR,
            segmented_button_selected_hover_color=ACCENT_HOVER,
            segmented_button_unselected_color=BG_INPUT,
            segmented_button_unselected_hover_color=BG_CARD_HOVER,
            width=400, height=530,
        )
        self.auth_tab.pack(fill="both", expand=True)
        self.auth_tab.add("Login")
        self.auth_tab.add("Sign Up")
        self.auth_tab.add("Request Key")

        self._build_login_tab(self.auth_tab.tab("Login"))
        self._build_signup_tab(self.auth_tab.tab("Sign Up"))
        self._build_request_key_tab(self.auth_tab.tab("Request Key"))

        self.auth_message = ctk.CTkLabel(
            container, text="", font=ctk.CTkFont(size=12), text_color=ERROR_COLOR, wraplength=400
        )
        self.auth_message.pack(pady=(10, 0))

        footer = ctk.CTkLabel(
            container, text="Powered by Greek Squad USA",
            font=ctk.CTkFont(size=11), text_color=TEXT_MUTED,
        )
        footer.pack(pady=(15, 0))

    def _build_login_tab(self, parent):
        ctk.CTkLabel(parent, text="Username", font=ctk.CTkFont(size=13, weight="bold"), text_color=TEXT_COLOR, anchor="w").pack(fill="x", pady=(10, 4))
        self.login_user = ctk.CTkEntry(
            parent, placeholder_text="Enter your username",
            fg_color=BG_INPUT, border_color=BORDER_COLOR, border_width=1,
            height=40, corner_radius=8, text_color=TEXT_COLOR,
        )
        self.login_user.pack(fill="x", pady=(0, 12))
        self.login_user.bind("<FocusIn>", lambda e: self.login_user.configure(border_color=ACCENT_COLOR))
        self.login_user.bind("<FocusOut>", lambda e: self.login_user.configure(border_color=BORDER_COLOR))

        ctk.CTkLabel(parent, text="Password", font=ctk.CTkFont(size=13, weight="bold"), text_color=TEXT_COLOR, anchor="w").pack(fill="x", pady=(0, 4))
        self.login_pass = ctk.CTkEntry(
            parent, placeholder_text="Enter your password", show="\u2022",
            fg_color=BG_INPUT, border_color=BORDER_COLOR, border_width=1,
            height=40, corner_radius=8, text_color=TEXT_COLOR,
        )
        self.login_pass.pack(fill="x", pady=(0, 18))
        self.login_pass.bind("<FocusIn>", lambda e: self.login_pass.configure(border_color=ACCENT_COLOR))
        self.login_pass.bind("<FocusOut>", lambda e: self.login_pass.configure(border_color=BORDER_COLOR))

        self.login_btn = ctk.CTkButton(
            parent, text="Sign In", font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, height=44,
            corner_radius=8, command=self._do_login
        )
        self.login_btn.pack(fill="x", pady=(0, 12))

        divider_frame = ctk.CTkFrame(parent, fg_color="transparent", height=20)
        divider_frame.pack(fill="x", pady=(0, 12))
        ctk.CTkFrame(divider_frame, fg_color=BORDER_COLOR, height=1).place(relx=0, rely=0.5, relwidth=0.4, anchor="w")
        ctk.CTkLabel(divider_frame, text="OR", font=ctk.CTkFont(size=11), text_color=TEXT_MUTED, fg_color=BG_CARD).place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkFrame(divider_frame, fg_color=BORDER_COLOR, height=1).place(relx=1.0, rely=0.5, relwidth=0.4, anchor="e")

        google_btn = ctk.CTkButton(
            parent, text="  Sign in with Google",
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#FFFFFF", hover_color="#F0F0F0", text_color="#3C4043",
            height=44, corner_radius=8, border_width=1, border_color=BORDER_COLOR,
            command=self._do_google_login
        )
        google_btn.pack(fill="x", pady=(0, 5))

    def _build_signup_tab(self, parent):
        ctk.CTkLabel(parent, text="Username", font=ctk.CTkFont(size=13, weight="bold"), text_color=TEXT_COLOR, anchor="w").pack(fill="x", pady=(8, 4))
        self.signup_user = ctk.CTkEntry(
            parent, placeholder_text="Choose a username",
            fg_color=BG_INPUT, border_color=BORDER_COLOR, border_width=1,
            height=40, corner_radius=8, text_color=TEXT_COLOR,
        )
        self.signup_user.pack(fill="x", pady=(0, 8))
        self.signup_user.bind("<FocusIn>", lambda e: self.signup_user.configure(border_color=ACCENT_COLOR))
        self.signup_user.bind("<FocusOut>", lambda e: self.signup_user.configure(border_color=BORDER_COLOR))

        ctk.CTkLabel(parent, text="Password", font=ctk.CTkFont(size=13, weight="bold"), text_color=TEXT_COLOR, anchor="w").pack(fill="x", pady=(0, 4))
        self.signup_pass = ctk.CTkEntry(
            parent, placeholder_text="Choose a password", show="\u2022",
            fg_color=BG_INPUT, border_color=BORDER_COLOR, border_width=1,
            height=40, corner_radius=8, text_color=TEXT_COLOR,
        )
        self.signup_pass.pack(fill="x", pady=(0, 8))
        self.signup_pass.bind("<FocusIn>", lambda e: self.signup_pass.configure(border_color=ACCENT_COLOR))
        self.signup_pass.bind("<FocusOut>", lambda e: self.signup_pass.configure(border_color=BORDER_COLOR))

        key_frame = ctk.CTkFrame(parent, fg_color="transparent")
        key_frame.pack(fill="x", pady=(0, 4))
        ctk.CTkLabel(key_frame, text="Authorization Key", font=ctk.CTkFont(size=13, weight="bold"), text_color=TEXT_COLOR, anchor="w").pack(side="left")
        ctk.CTkButton(
            key_frame, text="Get a Key", font=ctk.CTkFont(size=11, weight="bold"),
            fg_color="transparent", text_color=ACCENT_COLOR, hover_color=BG_INPUT,
            width=70, height=22, corner_radius=6,
            command=lambda: webbrowser.open("https://www.greeksquadusa.com/pricing.html")
        ).pack(side="right")

        self.signup_key = ctk.CTkEntry(
            parent, placeholder_text="Enter your authorization key",
            fg_color=BG_INPUT, border_color=BORDER_COLOR, border_width=1,
            height=40, corner_radius=8, text_color=TEXT_COLOR,
        )
        self.signup_key.pack(fill="x", pady=(0, 16))
        self.signup_key.bind("<FocusIn>", lambda e: self.signup_key.configure(border_color=ACCENT_COLOR))
        self.signup_key.bind("<FocusOut>", lambda e: self.signup_key.configure(border_color=BORDER_COLOR))

        ctk.CTkButton(
            parent, text="Create Account", font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, height=44,
            corner_radius=8, command=self._do_signup
        ).pack(fill="x", pady=(0, 8))

    def _build_request_key_tab(self, parent):
        ctk.CTkLabel(
            parent, text="Request an Activation Key",
            font=ctk.CTkFont(size=16, weight="bold"), text_color=ACCENT_COLOR
        ).pack(pady=(12, 6))

        ctk.CTkLabel(
            parent,
            text="Please send this email to our support team.\nOnce you receive your key, enter it below\nto activate your software.",
            font=ctk.CTkFont(size=12), text_color=TEXT_SECONDARY,
            justify="center",
        ).pack(pady=(0, 15))

        hwid_frame = ctk.CTkFrame(parent, fg_color=ACCENT_LIGHT, corner_radius=10, border_width=1, border_color=ACCENT_COLOR)
        hwid_frame.pack(fill="x", padx=5, pady=(0, 8))

        ctk.CTkLabel(
            hwid_frame, text="Your Hardware ID",
            font=ctk.CTkFont(size=12, weight="bold"), text_color=ACCENT_HOVER
        ).pack(padx=12, pady=(10, 2), anchor="w")

        self.hwid_value = get_hardware_id()

        hwid_entry_frame = ctk.CTkFrame(hwid_frame, fg_color="transparent")
        hwid_entry_frame.pack(fill="x", padx=12, pady=(0, 10))

        self.hwid_display = ctk.CTkEntry(
            hwid_entry_frame,
            fg_color=BG_CARD, border_color=BORDER_COLOR, border_width=1,
            height=38, corner_radius=6, text_color=TEXT_COLOR,
            font=ctk.CTkFont(family="Courier", size=12),
        )
        self.hwid_display.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.hwid_display.insert(0, self.hwid_value)
        self.hwid_display.configure(state="disabled")

        copy_btn = ctk.CTkButton(
            hwid_entry_frame, text="Copy", width=60, height=38,
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, corner_radius=6,
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._copy_hwid
        )
        copy_btn.pack(side="right")

        self.hwid_status = ctk.CTkLabel(
            parent, text="", font=ctk.CTkFont(size=11), text_color=SUCCESS_COLOR
        )
        self.hwid_status.pack(pady=(0, 10))

        email_btn = ctk.CTkButton(
            parent, text="Email Support for Key",
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, height=46,
            corner_radius=8, command=self._email_support
        )
        email_btn.pack(fill="x", padx=5, pady=(0, 8))

        pricing_btn = ctk.CTkButton(
            parent, text="View Pricing Plans",
            font=ctk.CTkFont(size=13),
            fg_color="transparent", text_color=ACCENT_COLOR,
            hover_color=BG_INPUT, height=36, corner_radius=8,
            border_width=1, border_color=ACCENT_COLOR,
            command=lambda: webbrowser.open("https://www.greeksquadusa.com/pricing.html")
        )
        pricing_btn.pack(fill="x", padx=5, pady=(0, 10))

        ctk.CTkFrame(parent, fg_color=BORDER_COLOR, height=1).pack(fill="x", padx=5, pady=(0, 10))

        ctk.CTkLabel(parent, text="Enter your key below to activate:", font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT_COLOR, anchor="w").pack(fill="x", padx=5, pady=(0, 4))

        activate_frame = ctk.CTkFrame(parent, fg_color="transparent")
        activate_frame.pack(fill="x", padx=5)

        self.request_key_entry = ctk.CTkEntry(
            activate_frame, placeholder_text="Paste your activation key here",
            fg_color=BG_INPUT, border_color=BORDER_COLOR, border_width=1,
            height=40, corner_radius=8, text_color=TEXT_COLOR,
        )
        self.request_key_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.request_key_entry.bind("<FocusIn>", lambda e: self.request_key_entry.configure(border_color=ACCENT_COLOR))
        self.request_key_entry.bind("<FocusOut>", lambda e: self.request_key_entry.configure(border_color=BORDER_COLOR))

        ctk.CTkButton(
            activate_frame, text="Activate", width=80, height=40,
            fg_color=SUCCESS_COLOR, hover_color="#15803D", corner_radius=8,
            font=ctk.CTkFont(size=13, weight="bold"),
            command=self._activate_with_key
        ).pack(side="right")

    def _copy_hwid(self):
        self.clipboard_clear()
        self.clipboard_append(self.hwid_value)
        self.hwid_status.configure(text="Hardware ID copied to clipboard!", text_color=SUCCESS_COLOR)
        aid = self.after(3000, lambda: self.hwid_status.configure(text=""))
        self._animation_ids.append(aid)

    def _email_support(self):
        subject = urllib.parse.quote("Activation Key Request")
        body = urllib.parse.quote(
            f"Hello Greek Squad Support,\n\n"
            f"I would like to request an activation key for Squad Driver Updater.\n\n"
            f"My Hardware ID: {self.hwid_value}\n\n"
            f"Please provide me with an activation key at your earliest convenience.\n\n"
            f"Thank you."
        )
        mailto_url = f"mailto:support@greeksquadusa.com?subject={subject}&body={body}"
        webbrowser.open(mailto_url)
        self.auth_message.configure(
            text="Email client opened! Send the email and wait for your activation key.",
            text_color=SUCCESS_COLOR
        )

    def _activate_with_key(self):
        key = self.request_key_entry.get().strip()
        if not key:
            self.auth_message.configure(text="Please enter an activation key.", text_color=ERROR_COLOR)
            return
        if key in VALID_AUTH_KEYS:
            self.auth_message.configure(text="Key validated! Go to the Sign Up tab to create your account.", text_color=SUCCESS_COLOR)
            self.auth_tab.set("Sign Up")
            self.signup_key.delete(0, "end")
            self.signup_key.insert(0, key)
        else:
            self.auth_message.configure(text="Invalid activation key. Please check and try again.", text_color=ERROR_COLOR)

    def _do_login(self):
        username = _sanitize_input(self.login_user.get())
        password = self.login_pass.get().strip()
        if not username or not password:
            self._shake_widget(self.login_btn)
            self.auth_message.configure(text="Please fill in all fields.", text_color=ERROR_COLOR)
            return
        rate_check = _check_rate_limit(username)
        if rate_check is not True:
            self._shake_widget(self.login_btn)
            mins = rate_check // 60
            self.auth_message.configure(text=f"Too many failed attempts. Try again in {mins} min.", text_color=ERROR_COLOR)
            return
        users = load_users()
        if username not in users or not verify_password(password, users[username]["password"]):
            _record_failed_login(username)
            self._shake_widget(self.login_btn)
            self.auth_message.configure(text="Invalid username or password.", text_color=ERROR_COLOR)
            return
        _clear_login_attempts(username)
        if not users[username]["password"].startswith("$2"):
            users[username]["password"] = hash_password(password)
            save_users(users)
        self.current_user = username
        self.login_btn.configure(fg_color=SUCCESS_COLOR, text="Success!")
        self.auth_message.configure(text="Login successful! Loading dashboard...", text_color=SUCCESS_COLOR)
        self.after(700, self.show_dashboard)

    def _shake_widget(self, widget, step=0):
        offsets = [8, -8, 6, -6, 4, -4, 2, -2, 0]
        if step < len(offsets):
            try:
                widget.configure(fg_color=ERROR_COLOR if step % 2 == 0 else ACCENT_COLOR)
            except Exception:
                pass
            aid = self.after(50, self._shake_widget, widget, step + 1)
            self._animation_ids.append(aid)
        else:
            try:
                widget.configure(fg_color=ACCENT_COLOR)
            except Exception:
                pass

    def _do_signup(self):
        username = _sanitize_input(self.signup_user.get())
        password = self.signup_pass.get().strip()
        auth_key = self.signup_key.get().strip()
        if not username or not password or not auth_key:
            self.auth_message.configure(text="Please fill in all fields.", text_color=ERROR_COLOR)
            return
        if len(username) < 3:
            self.auth_message.configure(text="Username must be at least 3 characters.", text_color=ERROR_COLOR)
            return
        if len(password) < 8:
            self.auth_message.configure(text="Password must be at least 8 characters.", text_color=ERROR_COLOR)
            return
        if auth_key not in VALID_AUTH_KEYS:
            self.auth_message.configure(text="Invalid authorization key. Click 'Get a Key' to purchase one.", text_color=ERROR_COLOR)
            return
        users = load_users()
        if username in users:
            self.auth_message.configure(text="Username already taken. Please choose another.", text_color=ERROR_COLOR)
            return
        users[username] = {"password": hash_password(password), "auth_key": auth_key, "created": datetime.now().isoformat(), "login_type": "local"}
        save_users(users)
        self.current_user = username
        self.auth_message.configure(text="Account created! Loading dashboard...", text_color=SUCCESS_COLOR)
        self.after(800, self.show_dashboard)

    def _do_google_login(self):
        if self.google_login_in_progress:
            return

        if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
            self.auth_message.configure(
                text="Google login requires GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables to be configured.",
                text_color=WARNING_COLOR
            )
            return

        self.google_login_in_progress = True
        self.auth_message.configure(text="Opening browser for Google sign-in...", text_color=ACCENT_COLOR)

        thread = threading.Thread(target=self._google_oauth_flow, daemon=True)
        thread.start()

    def _google_oauth_flow(self):
        try:
            state = secrets.token_urlsafe(32)
            auth_params = urllib.parse.urlencode({
                "client_id": GOOGLE_CLIENT_ID,
                "redirect_uri": GOOGLE_REDIRECT_URI,
                "response_type": "code",
                "scope": "openid email profile",
                "state": state,
                "access_type": "offline",
                "prompt": "select_account",
            })
            auth_url = f"{GOOGLE_AUTH_URL}?{auth_params}"

            server = http.server.HTTPServer(("localhost", 8765), GoogleOAuthHandler)
            server.auth_code = None
            server.auth_error = None
            server.expected_state = state
            server.should_stop = False
            server.timeout = 120

            webbrowser.open(auth_url)

            start_time = time.time()
            while not server.should_stop and (time.time() - start_time) < 120:
                server.handle_request()

            if server.auth_error:
                self.after(0, lambda: self.auth_message.configure(text="Google sign-in failed. Please try again.", text_color=ERROR_COLOR))
            elif not server.auth_code and not server.auth_error:
                self.after(0, lambda: self.auth_message.configure(text="Google sign-in timed out. Please try again.", text_color=WARNING_COLOR))
            elif server.auth_code:
                import urllib.request
                token_data = urllib.parse.urlencode({
                    "code": server.auth_code,
                    "client_id": GOOGLE_CLIENT_ID,
                    "client_secret": GOOGLE_CLIENT_SECRET,
                    "redirect_uri": GOOGLE_REDIRECT_URI,
                    "grant_type": "authorization_code",
                }).encode()

                req = urllib.request.Request(GOOGLE_TOKEN_URL, data=token_data, method="POST")
                req.add_header("Content-Type", "application/x-www-form-urlencoded")
                with urllib.request.urlopen(req) as resp:
                    token_response = json.loads(resp.read().decode())

                access_token = token_response.get("access_token")
                if access_token:
                    userinfo_req = urllib.request.Request(GOOGLE_USERINFO_URL)
                    userinfo_req.add_header("Authorization", f"Bearer {access_token}")
                    with urllib.request.urlopen(userinfo_req) as resp:
                        user_info = json.loads(resp.read().decode())

                    email = user_info.get("email", "")
                    name = user_info.get("name", email)
                    google_id = user_info.get("id", "")

                    users = load_users()
                    google_username = f"google_{google_id}"
                    if google_username not in users:
                        users[google_username] = {
                            "password": "",
                            "email": email,
                            "name": name,
                            "google_id": google_id,
                            "auth_key": "GOOGLE-AUTH",
                            "created": datetime.now().isoformat(),
                            "login_type": "google",
                        }
                        save_users(users)

                    self.current_user = name or email
                    self.after(0, lambda: self.auth_message.configure(text=f"Welcome, {name}! Loading dashboard...", text_color=SUCCESS_COLOR))
                    self.after(800, self.show_dashboard)
                else:
                    self.after(0, lambda: self.auth_message.configure(text="Failed to get access token from Google.", text_color=ERROR_COLOR))
            else:
                self.after(0, lambda: self.auth_message.configure(text="Google sign-in was cancelled.", text_color=WARNING_COLOR))

        except OSError as e:
            if "Address already in use" in str(e):
                self.after(0, lambda: self.auth_message.configure(text="Auth server port in use. Please try again.", text_color=ERROR_COLOR))
            else:
                self.after(0, lambda: self.auth_message.configure(text="Google login encountered a network error. Please try again.", text_color=ERROR_COLOR))
        except Exception:
            self.after(0, lambda: self.auth_message.configure(text="Google login failed. Please try again.", text_color=ERROR_COLOR))
        finally:
            self.google_login_in_progress = False

    def show_dashboard(self):
        self.clear_window()

        top_bar = ctk.CTkFrame(self, fg_color=BG_CARD, height=56, corner_radius=0, border_width=0)
        top_bar.pack(fill="x", side="top")
        top_bar.pack_propagate(False)

        brand_frame = ctk.CTkFrame(top_bar, fg_color="transparent")
        brand_frame.pack(side="left", padx=20)

        ctk.CTkLabel(brand_frame, image=self.logo_image_small, text="").pack(side="left", padx=(0, 10))

        ctk.CTkLabel(
            brand_frame, text="Squad Driver Updater",
            font=ctk.CTkFont(size=18, weight="bold"), text_color=TEXT_COLOR
        ).pack(side="left")

        user_frame = ctk.CTkFrame(top_bar, fg_color="transparent")
        user_frame.pack(side="right", padx=20)

        user_badge = ctk.CTkFrame(user_frame, fg_color=ACCENT_LIGHT, corner_radius=8, border_width=1, border_color=ACCENT_COLOR)
        user_badge.pack(side="left", padx=(0, 10))
        ctk.CTkLabel(user_badge, text=f"  {self.current_user}  ", font=ctk.CTkFont(size=12, weight="bold"), text_color=ACCENT_HOVER).pack(padx=8, pady=4)

        ctk.CTkButton(
            user_frame, text="Logout", width=75, height=32,
            fg_color="transparent", border_width=1, border_color=BORDER_COLOR,
            text_color=TEXT_SECONDARY, hover_color=BG_INPUT,
            corner_radius=8, font=ctk.CTkFont(size=12),
            command=self.show_login_screen
        ).pack(side="left")

        accent_line = ctk.CTkFrame(self, fg_color=ACCENT_COLOR, height=3, corner_radius=0)
        accent_line.pack(fill="x")
        self._animate_accent_line(accent_line)

        main_area = ctk.CTkFrame(self, fg_color=BG_DARK)
        main_area.pack(fill="both", expand=True, padx=0, pady=0)

        tabs = ctk.CTkTabview(
            main_area, fg_color=BG_CARD, corner_radius=0,
            segmented_button_selected_color=ACCENT_COLOR,
            segmented_button_selected_hover_color=ACCENT_HOVER,
            segmented_button_unselected_color=BG_INPUT,
            segmented_button_unselected_hover_color=BG_CARD_HOVER,
            border_width=0,
        )
        tabs.pack(fill="both", expand=True, padx=12, pady=12)

        tab_names = ["System Repair", "Cleaner", "Network", "Antivirus", "Drivers"]
        for name in tab_names:
            tabs.add(name)

        self._build_system_repair_tab(tabs.tab("System Repair"))
        self._build_cleaner_tab(tabs.tab("Cleaner"))
        self._build_network_tab(tabs.tab("Network"))
        self._build_antivirus_tab(tabs.tab("Antivirus"))
        self._build_drivers_tab(tabs.tab("Drivers"))

        status_bar = ctk.CTkFrame(self, fg_color=BG_CARD, height=28, corner_radius=0)
        status_bar.pack(fill="x", side="bottom")
        status_bar.pack_propagate(False)

        self.status_dot = ctk.CTkFrame(status_bar, fg_color=SUCCESS_COLOR, width=8, height=8, corner_radius=4)
        self.status_dot.pack(side="left", padx=(12, 6), pady=10)
        self._pulse_widget(self.status_dot, [SUCCESS_COLOR, "#2da44e", SUCCESS_COLOR])

        self.status_label = ctk.CTkLabel(status_bar, text="Ready", font=ctk.CTkFont(size=11), text_color=TEXT_MUTED)
        self.status_label.pack(side="left")
        ctk.CTkLabel(status_bar, text=f"v{CURRENT_VERSION}  ", font=ctk.CTkFont(size=11), text_color=TEXT_MUTED).pack(side="right", padx=10)

        threading.Thread(target=self._check_for_updates, daemon=True).start()

    def _check_for_updates(self):
        try:
            response = requests.get(VERSION_URL, timeout=10)
            latest_version = response.text.strip()
            if latest_version > CURRENT_VERSION:
                self.after(0, lambda: self._show_update_banner(latest_version))
        except Exception:
            pass

    def _show_update_banner(self, latest_version):
        try:
            self.status_label.configure(
                text=f"Update available: v{latest_version}",
                text_color=WARNING_COLOR
            )
            self.status_dot.configure(fg_color=WARNING_COLOR)
            self._pulse_widget(self.status_dot, [WARNING_COLOR, "#B45309", WARNING_COLOR])

            banner = ctk.CTkFrame(self, fg_color=ACCENT_LIGHT, height=36, corner_radius=0, border_width=0)
            banner.pack(fill="x", side="top", before=self.winfo_children()[2] if len(self.winfo_children()) > 2 else None)
            banner.pack_propagate(False)

            ctk.CTkLabel(
                banner, text=f"A new update (v{latest_version}) is available!",
                font=ctk.CTkFont(size=12, weight="bold"), text_color=ACCENT_COLOR
            ).pack(side="left", padx=15)

            ctk.CTkButton(
                banner, text="Download Update", width=120, height=26,
                fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER, corner_radius=6,
                font=ctk.CTkFont(size=11, weight="bold"),
                command=lambda: webbrowser.open("https://www.greeksquadusa.com/download.html")
            ).pack(side="right", padx=15)
        except Exception:
            pass

    def _animate_accent_line(self, line, step=0):
        colors = [ACCENT_COLOR, ACCENT_HOVER, "#005A82", ACCENT_HOVER, ACCENT_COLOR]
        idx = step % len(colors)
        try:
            line.configure(fg_color=colors[idx])
        except Exception:
            return
        aid = self.after(1200, self._animate_accent_line, line, step + 1)
        self._animation_ids.append(aid)

    def _create_tab_header(self, parent, title, description, icon=""):
        header_frame = ctk.CTkFrame(parent, fg_color="transparent")
        header_frame.pack(fill="x", padx=15, pady=(12, 5))

        title_row = ctk.CTkFrame(header_frame, fg_color="transparent")
        title_row.pack(fill="x")

        if icon:
            icon_badge = ctk.CTkFrame(title_row, fg_color=ACCENT_LIGHT, corner_radius=8, width=36, height=36)
            icon_badge.pack(side="left", padx=(0, 10))
            icon_badge.pack_propagate(False)
            ctk.CTkLabel(icon_badge, text=icon, font=ctk.CTkFont(size=18), text_color=ACCENT_COLOR).place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(title_row, text=title, font=ctk.CTkFont(size=20, weight="bold"), text_color=TEXT_COLOR).pack(side="left")

        ctk.CTkLabel(header_frame, text=description, font=ctk.CTkFont(size=12), text_color=TEXT_SECONDARY, anchor="w").pack(fill="x", pady=(4, 0))

        ctk.CTkFrame(header_frame, fg_color=BORDER_COLOR, height=1).pack(fill="x", pady=(10, 0))

    def _create_log_area(self, parent):
        log_frame = ctk.CTkFrame(parent, fg_color=BG_INPUT, corner_radius=8, border_width=1, border_color=BORDER_COLOR)
        log_frame.pack(fill="both", expand=True, padx=15, pady=(8, 12))

        log_header = ctk.CTkFrame(log_frame, fg_color="transparent")
        log_header.pack(fill="x", padx=12, pady=(8, 0))
        ctk.CTkLabel(log_header, text="Output Log", font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT_SECONDARY, anchor="w").pack(side="left")

        status_dot = ctk.CTkFrame(log_header, fg_color=SUCCESS_COLOR, width=8, height=8, corner_radius=4)
        status_dot.pack(side="right", padx=(0, 4))
        ctk.CTkLabel(log_header, text="Ready", font=ctk.CTkFont(size=11), text_color=TEXT_MUTED).pack(side="right", padx=(0, 6))

        log_box = ctk.CTkTextbox(
            log_frame, fg_color="#FAFBFC", text_color="#0550AE",
            font=ctk.CTkFont(family="Courier", size=12),
            corner_radius=6, wrap="word",
            border_width=1, border_color=BORDER_COLOR,
        )
        log_box.pack(fill="both", expand=True, padx=12, pady=(6, 12))
        log_box.configure(state="disabled")
        return log_box

    def _append_log(self, log_box, text):
        log_box.configure(state="normal")
        log_box.insert("end", text + "\n")
        log_box.see("end")
        log_box.configure(state="disabled")

    _ALLOWED_COMMANDS = {
        "sfc /scannow": ["sfc", "/scannow"],
        "DISM /Online /Cleanup-Image /CheckHealth": ["DISM", "/Online", "/Cleanup-Image", "/CheckHealth"],
        "DISM /Online /Cleanup-Image /ScanHealth": ["DISM", "/Online", "/Cleanup-Image", "/ScanHealth"],
        "DISM /Online /Cleanup-Image /RestoreHealth": ["DISM", "/Online", "/Cleanup-Image", "/RestoreHealth"],
        "cleanmgr": ["cleanmgr"],
        'del /q/f/s "%TEMP%\\*" 2>nul': ["del", "/q/f/s", "%TEMP%\\*", "2>nul"],
        'del /q/f/s "C:\\Windows\\Temp\\*" 2>nul': ["del", "/q/f/s", "C:\\Windows\\Temp\\*", "2>nul"],
        'del /q/f/s "C:\\Windows\\Prefetch\\*" 2>nul': ["del", "/q/f/s", "C:\\Windows\\Prefetch\\*", "2>nul"],
        "ipconfig /flushdns": ["ipconfig", "/flushdns"],
        "netsh winsock reset": ["netsh", "winsock", "reset"],
        "netsh int ip reset": ["netsh", "int", "ip", "reset"],
        "ipconfig /release && ipconfig /renew": ["ipconfig", "/release", "&&", "ipconfig", "/renew"],
        '"C:\\Program Files\\Windows Defender\\MpCmdRun.exe" -Scan -ScanType 1': ["C:\\Program Files\\Windows Defender\\MpCmdRun.exe", "-Scan", "-ScanType", "1"],
        '"C:\\Program Files\\Windows Defender\\MpCmdRun.exe" -Scan -ScanType 2': ["C:\\Program Files\\Windows Defender\\MpCmdRun.exe", "-Scan", "-ScanType", "2"],
        '"C:\\Program Files\\Windows Defender\\MpCmdRun.exe" -SignatureUpdate': ["C:\\Program Files\\Windows Defender\\MpCmdRun.exe", "-SignatureUpdate"],
        "driverquery /v": ["driverquery", "/v"],
        "pnputil /enum-drivers": ["pnputil", "/enum-drivers"],
        "driverquery /si": ["driverquery", "/si"],
    }

    def _run_command(self, cmd, log_box, description=""):
        cmd_args = self._ALLOWED_COMMANDS.get(cmd)
        if cmd_args is None:
            self._append_log(log_box, f"\n\u2717 Blocked unrecognized command: {shlex.quote(cmd)}\n")
            return

        def worker():
            self._append_log(log_box, f"\u250c{'─'*48}\u2510")
            self._append_log(log_box, f"\u2502 [{datetime.now().strftime('%H:%M:%S')}] {description}")
            self._append_log(log_box, f"\u2502 Command: {cmd}")
            self._append_log(log_box, f"\u2514{'─'*48}\u2518")
            self._append_log(log_box, "")
            self._append_log(log_box, "\u25b6 NOTE: Running in Linux/Replit environment.")
            self._append_log(log_box, "  Windows commands will be simulated here.")
            self._append_log(log_box, "  On Windows, these execute with admin privileges.")
            self._append_log(log_box, "")

            try:
                process = subprocess.Popen(
                    cmd_args,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    text=True
                )
                for line in iter(process.stdout.readline, ''):
                    self.after(0, self._append_log, log_box, f"  {line.rstrip()}")
                for line in iter(process.stderr.readline, ''):
                    self.after(0, self._append_log, log_box, f"  \u26a0 {line.rstrip()}")
                process.wait()

                if process.returncode == 0:
                    self.after(0, self._append_log, log_box, f"\n\u2713 {description} completed successfully.\n")
                else:
                    self.after(0, self._append_log, log_box, f"\n\u25b6 Command returned code {process.returncode}.")
                    self.after(0, self._append_log, log_box, "  On Windows, run as Administrator for full access.\n")
            except FileNotFoundError:
                self.after(0, self._append_log, log_box, f"\n\u25b6 '{cmd.split()[0]}' is a Windows-specific command.")
                self.after(0, self._append_log, log_box, "  This will work when running on Windows.")
                self.after(0, self._append_log, log_box, "  Run the application as Administrator.\n")
            except Exception as e:
                self.after(0, self._append_log, log_box, f"\n\u2717 Error: {str(e)}\n")

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()

    def _create_action_button(self, parent, text, command, icon_text=""):
        btn = ctk.CTkButton(
            parent, text=f"  {icon_text}  {text}" if icon_text else f"  {text}",
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=ACCENT_COLOR, hover_color=ACCENT_HOVER,
            height=42, anchor="w", corner_radius=8,
            command=command
        )
        btn.pack(fill="x", padx=15, pady=3)
        return btn

    def _build_system_repair_tab(self, parent):
        self._create_tab_header(parent, "System Repair", "Scan and repair Windows system files using built-in tools", "\u26e9")

        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.pack(fill="x", pady=(5, 0))

        log_box = self._create_log_area(parent)

        btns = []
        btns.append(self._create_action_button(btn_frame, "Run SFC Scan (System File Checker)",
            lambda: self._run_command("sfc /scannow", log_box, "SFC System File Checker"), "\u25b6"))
        btns.append(self._create_action_button(btn_frame, "DISM - Check Health",
            lambda: self._run_command("DISM /Online /Cleanup-Image /CheckHealth", log_box, "DISM CheckHealth"), "\u25b6"))
        btns.append(self._create_action_button(btn_frame, "DISM - Scan Health",
            lambda: self._run_command("DISM /Online /Cleanup-Image /ScanHealth", log_box, "DISM ScanHealth"), "\u25b6"))
        btns.append(self._create_action_button(btn_frame, "DISM - Restore Health",
            lambda: self._run_command("DISM /Online /Cleanup-Image /RestoreHealth", log_box, "DISM RestoreHealth"), "\u25b6"))

    def _build_cleaner_tab(self, parent):
        self._create_tab_header(parent, "System Cleaner", "Clean temporary files and free up disk space", "\u2728")

        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.pack(fill="x", pady=(5, 0))

        log_box = self._create_log_area(parent)

        self._create_action_button(btn_frame, "Open Disk Cleanup (cleanmgr)",
            lambda: self._run_command("cleanmgr", log_box, "Disk Cleanup Utility"), "\u25b6")
        self._create_action_button(btn_frame, "Clear Temp Folder (%TEMP%)",
            lambda: self._run_command('del /q/f/s "%TEMP%\\*" 2>nul', log_box, "Clear %TEMP% folder"), "\u25b6")
        self._create_action_button(btn_frame, "Clear Windows Temp Folder",
            lambda: self._run_command('del /q/f/s "C:\\Windows\\Temp\\*" 2>nul', log_box, "Clear Windows Temp folder"), "\u25b6")
        self._create_action_button(btn_frame, "Clear Prefetch Files",
            lambda: self._run_command('del /q/f/s "C:\\Windows\\Prefetch\\*" 2>nul', log_box, "Clear Prefetch files"), "\u25b6")

    def _build_network_tab(self, parent):
        self._create_tab_header(parent, "Network Tools", "Reset and repair network configurations", "\u21ba")

        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.pack(fill="x", pady=(5, 0))

        log_box = self._create_log_area(parent)

        self._create_action_button(btn_frame, "Flush DNS Cache",
            lambda: self._run_command("ipconfig /flushdns", log_box, "Flush DNS Cache"), "\u25b6")
        self._create_action_button(btn_frame, "Reset Winsock Catalog",
            lambda: self._run_command("netsh winsock reset", log_box, "Winsock Reset"), "\u25b6")
        self._create_action_button(btn_frame, "Reset TCP/IP Stack",
            lambda: self._run_command("netsh int ip reset", log_box, "TCP/IP Reset"), "\u25b6")
        self._create_action_button(btn_frame, "Release & Renew IP Address",
            lambda: self._run_command("ipconfig /release && ipconfig /renew", log_box, "IP Release & Renew"), "\u25b6")

    def _build_antivirus_tab(self, parent):
        self._create_tab_header(parent, "Antivirus Scanner", "Run Windows Defender scans to detect threats", "\u2603")

        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.pack(fill="x", pady=(5, 0))

        log_box = self._create_log_area(parent)

        defender_path = '"C:\\Program Files\\Windows Defender\\MpCmdRun.exe"'

        self._create_action_button(btn_frame, "Quick Scan",
            lambda: self._run_command(f"{defender_path} -Scan -ScanType 1", log_box, "Windows Defender Quick Scan"), "\u25b6")
        self._create_action_button(btn_frame, "Full Scan",
            lambda: self._run_command(f"{defender_path} -Scan -ScanType 2", log_box, "Windows Defender Full Scan"), "\u25b6")
        self._create_action_button(btn_frame, "Update Virus Definitions",
            lambda: self._run_command(f"{defender_path} -SignatureUpdate", log_box, "Update Defender Signatures"), "\u25b6")

    def _build_drivers_tab(self, parent):
        self._create_tab_header(parent, "Driver Information", "Query and inspect installed system drivers", "\u2630")

        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.pack(fill="x", pady=(5, 0))

        log_box = self._create_log_area(parent)

        self._create_action_button(btn_frame, "List All Drivers (driverquery)",
            lambda: self._run_command("driverquery /v", log_box, "Driver Query - Verbose"), "\u25b6")
        self._create_action_button(btn_frame, "Enumerate PnP Drivers",
            lambda: self._run_command("pnputil /enum-drivers", log_box, "PnP Utility - Enumerate Drivers"), "\u25b6")
        self._create_action_button(btn_frame, "List Signed Drivers Only",
            lambda: self._run_command("driverquery /si", log_box, "Driver Query - Signed Info"), "\u25b6")


if __name__ == "__main__":
    app = App()
    app.mainloop()
