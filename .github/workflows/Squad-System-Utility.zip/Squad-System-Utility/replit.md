# Squad Driver Updater

## Overview
A Python-based Windows System Utility web application using Flask with a modern light-themed UI (#0096D6 blue accents). The app provides system repair, cleaning, networking, antivirus, and driver management tools with Google OAuth login support. Originally a CustomTkinter desktop app, converted to Flask web app for deployment compatibility.

## Project Architecture
- **app.py**: Flask web application with auth, command execution, and SSE streaming
- **main.py**: Original desktop GUI app (kept for reference, not used in deployment)
- **templates/login.html**: Login/signup/request-key page
- **templates/dashboard.html**: Main dashboard with 5 tool tabs
- **static/css/style.css**: All styling matching original #0096D6 accent design
- **static/images/logo.png**: Greek Squad USA logo
- **static/images/favicon.png**: Browser favicon
- **assets/logo.png**: Original logo asset
- **users.json**: User database (auto-created, gitignored, file permissions 0o600)

## Key Features
- Login/Signup with authorization key validation (links to greeksquadusa.com/pricing.html)
- Google OAuth login via standard web redirect flow
- **7-day free trial**: Name + email signup only, limited to System Repair tab (4 other tabs locked with upgrade prompts)
- Request Key tab: Hardware ID detection, mailto support@greeksquadusa.com, inline key activation
- 5-tab dashboard: System Repair, Cleaner, Network, Antivirus, Drivers
- Server-Sent Events (SSE) for real-time command output streaming
- Allowlisted command execution with subprocess (no shell=True)
- CSS animations: slide-up login, accent line pulse, status dot pulse
- Input focus effects (border highlights)
- Responsive web design

## Security
- **Password hashing**: bcrypt with automatic salt (backward compatible with legacy SHA-256 hashes, auto-upgrades on login)
- **Rate limiting**: 5 login attempts per username, 5-minute lockout after exceeded
- **Input sanitization**: Username and inputs sanitized (special chars stripped, length limited)
- **Command allowlist**: Only predefined commands can be executed via API
- **Session-based auth**: Flask sessions with login_required decorator
- **File permissions**: users.json created with 0o600 (owner read/write only)
- **Error messages**: Generic error messages on login failure and OAuth errors (no info leakage)
- **Auth keys**: Loaded from SQUAD_AUTH_KEYS environment variable (comma-separated), defaults provided for dev
- **Cache control**: No-cache headers on all responses

## Environment Variables
- **FLASK_SECRET_KEY**: Flask session secret key (auto-generated if not set)
- **GOOGLE_CLIENT_ID**: Google OAuth client ID
- **GOOGLE_CLIENT_SECRET**: Google OAuth client secret
- **SQUAD_AUTH_KEYS**: Comma-separated valid authorization keys (defaults provided for dev/testing)

## Google OAuth Setup
- Requires GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables
- Uses web redirect flow with dynamic redirect URI based on request host
- Exchanges auth code for access token and fetches user profile
- CSRF protection via state parameter stored in session

## Deployment
- **Target**: Autoscale (Cloud Run compatible)
- **Run command**: `python app.py`
- **Port**: 5000
- Flask development server used; consider gunicorn for production

## Technical Notes
- Commands are Windows-specific; running on Linux shows informational messages
- Password minimum 8 characters for signup
- Color scheme: BG #F0F2F5, Cards #FFFFFF, Accent #0096D6

## Default Auth Keys (dev/testing only, configure SQUAD_AUTH_KEYS in production)
- SQUAD-PRO-2024
- SQUAD-PREMIUM-2024
- SQUAD-ULTIMATE-2024
- GREEK-SQUAD-KEY

## Free Trial System
- Trial users stored in users.json with `login_type: "trial"` and `trial_start` timestamp
- Username format: `trial_{email}` to prevent conflicts with regular users
- Trial duration: 7 days from signup (configurable via TRIAL_DURATION_DAYS constant)
- Allowed commands during trial: sfc_scannow, dism_checkhealth, dism_scanhealth, dism_restorehealth (System Repair only)
- Backend enforces command restrictions via TRIAL_ALLOWED_COMMANDS set
- Expired trials are auto-detected on login and session is cleared with upgrade message
- Dashboard shows trial banner, days remaining badge, and locked tab overlays with upgrade links

## Recent Changes
- 2026-02-24: Added 7-day free trial feature with name/email signup, limited to System Repair tab
- 2026-02-24: Converted from CustomTkinter desktop app to Flask web application for deployment compatibility
