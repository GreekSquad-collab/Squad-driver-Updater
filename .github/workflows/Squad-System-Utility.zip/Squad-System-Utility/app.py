import os
import json
import time
import stat
import re
import shlex
import secrets
import hashlib
import subprocess
import threading
import platform
import uuid
from datetime import datetime
from collections import deque

import bcrypt
import requests
from flask import (
    Flask, render_template, request, redirect, url_for,
    session, jsonify, Response, stream_with_context
)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", secrets.token_hex(32))

DB_FILE = "users.json"
CURRENT_VERSION = "1.0"
VERSION_URL = "https://www.greeksquadusa.com/version.txt"

VALID_AUTH_KEYS = os.environ.get(
    "SQUAD_AUTH_KEYS",
    "SQUAD-PRO-2024,SQUAD-PREMIUM-2024,SQUAD-ULTIMATE-2024,GREEK-SQUAD-KEY"
).split(",")

GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")
GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo"

MAX_LOGIN_ATTEMPTS = 5
LOGIN_LOCKOUT_SECONDS = 300
_login_attempts = {}

_jobs = {}
_jobs_lock = threading.Lock()

TRIAL_DURATION_DAYS = 7
TRIAL_ALLOWED_COMMANDS = {"sfc_scannow", "dism_checkhealth", "dism_scanhealth", "dism_restorehealth"}

ALLOWED_COMMANDS = {
    "sfc_scannow": {
        "display": "sfc /scannow",
        "args": ["sfc", "/scannow"],
        "description": "SFC System File Checker",
    },
    "dism_checkhealth": {
        "display": "DISM /Online /Cleanup-Image /CheckHealth",
        "args": ["DISM", "/Online", "/Cleanup-Image", "/CheckHealth"],
        "description": "DISM CheckHealth",
    },
    "dism_scanhealth": {
        "display": "DISM /Online /Cleanup-Image /ScanHealth",
        "args": ["DISM", "/Online", "/Cleanup-Image", "/ScanHealth"],
        "description": "DISM ScanHealth",
    },
    "dism_restorehealth": {
        "display": "DISM /Online /Cleanup-Image /RestoreHealth",
        "args": ["DISM", "/Online", "/Cleanup-Image", "/RestoreHealth"],
        "description": "DISM RestoreHealth",
    },
    "cleanmgr": {
        "display": "cleanmgr",
        "args": ["cleanmgr"],
        "description": "Disk Cleanup Utility",
    },
    "clear_temp": {
        "display": 'del /q/f/s "%TEMP%\\*"',
        "args": ["del", "/q/f/s", "%TEMP%\\*", "2>nul"],
        "description": "Clear %TEMP% folder",
    },
    "clear_win_temp": {
        "display": 'del /q/f/s "C:\\Windows\\Temp\\*"',
        "args": ["del", "/q/f/s", "C:\\Windows\\Temp\\*", "2>nul"],
        "description": "Clear Windows Temp folder",
    },
    "clear_prefetch": {
        "display": 'del /q/f/s "C:\\Windows\\Prefetch\\*"',
        "args": ["del", "/q/f/s", "C:\\Windows\\Prefetch\\*", "2>nul"],
        "description": "Clear Prefetch files",
    },
    "flush_dns": {
        "display": "ipconfig /flushdns",
        "args": ["ipconfig", "/flushdns"],
        "description": "Flush DNS Cache",
    },
    "winsock_reset": {
        "display": "netsh winsock reset",
        "args": ["netsh", "winsock", "reset"],
        "description": "Winsock Reset",
    },
    "tcpip_reset": {
        "display": "netsh int ip reset",
        "args": ["netsh", "int", "ip", "reset"],
        "description": "TCP/IP Reset",
    },
    "ip_renew": {
        "display": "ipconfig /release && ipconfig /renew",
        "args": ["ipconfig", "/release", "&&", "ipconfig", "/renew"],
        "description": "IP Release & Renew",
    },
    "defender_quick": {
        "display": "MpCmdRun.exe -Scan -ScanType 1",
        "args": ["C:\\Program Files\\Windows Defender\\MpCmdRun.exe", "-Scan", "-ScanType", "1"],
        "description": "Windows Defender Quick Scan",
    },
    "defender_full": {
        "display": "MpCmdRun.exe -Scan -ScanType 2",
        "args": ["C:\\Program Files\\Windows Defender\\MpCmdRun.exe", "-Scan", "-ScanType", "2"],
        "description": "Windows Defender Full Scan",
    },
    "defender_update": {
        "display": "MpCmdRun.exe -SignatureUpdate",
        "args": ["C:\\Program Files\\Windows Defender\\MpCmdRun.exe", "-SignatureUpdate"],
        "description": "Update Defender Signatures",
    },
    "driverquery_v": {
        "display": "driverquery /v",
        "args": ["driverquery", "/v"],
        "description": "Driver Query - Verbose",
    },
    "pnputil_enum": {
        "display": "pnputil /enum-drivers",
        "args": ["pnputil", "/enum-drivers"],
        "description": "PnP Utility - Enumerate Drivers",
    },
    "driverquery_si": {
        "display": "driverquery /si",
        "args": ["driverquery", "/si"],
        "description": "Driver Query - Signed Info",
    },
}


def load_users():
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r") as f:
            return json.load(f)
    return {}


def save_users(users):
    fd = os.open(DB_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(users, f, indent=2)
    try:
        os.chmod(DB_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def hash_password(password):
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(password, hashed):
    if hashed.startswith("$2"):
        return bcrypt.checkpw(password.encode(), hashed.encode())
    return hashlib.sha256(password.encode()).hexdigest() == hashed


def _sanitize_input(text, max_length=128):
    text = text.strip()[:max_length]
    return re.sub(r'[<>&"\']', '', text)


def _check_rate_limit(username):
    now = time.time()
    if username in _login_attempts:
        attempts, first_attempt = _login_attempts[username]
        if now - first_attempt > LOGIN_LOCKOUT_SECONDS:
            _login_attempts[username] = (0, now)
            return True
        if attempts >= MAX_LOGIN_ATTEMPTS:
            remaining = int(LOGIN_LOCKOUT_SECONDS - (now - first_attempt))
            return remaining
    return True


def _record_failed_login(username):
    now = time.time()
    if username in _login_attempts:
        attempts, first_attempt = _login_attempts[username]
        if now - first_attempt > LOGIN_LOCKOUT_SECONDS:
            _login_attempts[username] = (1, now)
        else:
            _login_attempts[username] = (attempts + 1, first_attempt)
    else:
        _login_attempts[username] = (1, now)


def _clear_login_attempts(username):
    _login_attempts.pop(username, None)


def get_hardware_id():
    try:
        if platform.system() == "Windows":
            result = subprocess.run(
                ["wmic", "csproduct", "get", "uuid"],
                capture_output=True, text=True, timeout=10
            )
            lines = [l.strip() for l in result.stdout.strip().split("\n") if l.strip() and l.strip() != "UUID"]
            if lines:
                return lines[0]
        result = subprocess.run(
            ["cat", "/etc/machine-id"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0 and result.stdout.strip():
            mid = result.stdout.strip().upper()
            return f"{mid[:8]}-{mid[8:12]}-{mid[12:16]}-{mid[16:20]}-{mid[20:32]}"
    except Exception:
        pass
    return "UNKNOWN-HWID-0000-0000-000000000000"


def get_user_trial_info(username):
    users = load_users()
    if username not in users:
        return None
    user = users[username]
    if user.get("login_type") != "trial":
        return None
    trial_start = datetime.fromisoformat(user["trial_start"])
    from datetime import timedelta
    trial_end = trial_start + timedelta(days=TRIAL_DURATION_DAYS)
    now = datetime.now()
    days_left = max(0, (trial_end - now).days)
    expired = now >= trial_end
    return {"days_left": days_left, "expired": expired, "trial_end": trial_end.isoformat()}


def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        trial_info = get_user_trial_info(session["user"])
        if trial_info and trial_info["expired"]:
            session.clear()
            return render_template("login.html", error="Your 7-day free trial has expired. Please sign up with an authorization key to continue.",
                                 google_enabled=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET))
        return f(*args, **kwargs)
    return decorated


@app.after_request
def add_no_cache(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


@app.route("/")
def index():
    if "user" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/privacy")
def privacy():
    return render_template("privacy.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    success = None
    if request.method == "POST":
        username = _sanitize_input(request.form.get("username", ""))
        password = request.form.get("password", "").strip()
        if not username or not password:
            error = "Please fill in all fields."
        else:
            rate_check = _check_rate_limit(username)
            if rate_check is not True:
                mins = rate_check // 60
                error = f"Too many failed attempts. Try again in {mins} min."
            else:
                users = load_users()
                if username not in users or not verify_password(password, users[username]["password"]):
                    _record_failed_login(username)
                    error = "Invalid username or password."
                else:
                    _clear_login_attempts(username)
                    if not users[username]["password"].startswith("$2"):
                        users[username]["password"] = hash_password(password)
                        save_users(users)
                    session["user"] = username
                    return redirect(url_for("dashboard"))
    return render_template("login.html", error=error, success=success,
                         google_enabled=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET))


@app.route("/signup", methods=["GET", "POST"])
def signup():
    error = None
    if request.method == "POST":
        username = _sanitize_input(request.form.get("username", ""))
        password = request.form.get("password", "").strip()
        auth_key = request.form.get("auth_key", "").strip()
        if not username or not password or not auth_key:
            error = "Please fill in all fields."
        elif len(username) < 3:
            error = "Username must be at least 3 characters."
        elif len(password) < 8:
            error = "Password must be at least 8 characters."
        elif auth_key not in VALID_AUTH_KEYS:
            error = "Invalid authorization key. Visit greeksquadusa.com/pricing.html to get one."
        else:
            users = load_users()
            if username in users:
                error = "Username already taken. Please choose another."
            else:
                users[username] = {
                    "password": hash_password(password),
                    "auth_key": auth_key,
                    "created": datetime.now().isoformat(),
                    "login_type": "local",
                }
                save_users(users)
                session["user"] = username
                return redirect(url_for("dashboard"))
    hwid = get_hardware_id()
    return render_template("login.html", signup_error=error, show_signup=True,
                         hwid=hwid, google_enabled=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET))


@app.route("/trial", methods=["GET", "POST"])
def trial_signup():
    error = None
    if request.method == "POST":
        name = _sanitize_input(request.form.get("name", ""))
        email = _sanitize_input(request.form.get("email", ""))
        if not name or not email:
            error = "Please fill in your name and email."
        elif len(name) < 2:
            error = "Name must be at least 2 characters."
        elif "@" not in email or "." not in email:
            error = "Please enter a valid email address."
        else:
            users = load_users()
            trial_username = f"trial_{email}"
            if trial_username in users:
                trial_info = get_user_trial_info(trial_username)
                if trial_info and trial_info["expired"]:
                    error = "Your free trial has already expired. Please sign up with an authorization key."
                else:
                    session["user"] = trial_username
                    return redirect(url_for("dashboard"))
            else:
                users[trial_username] = {
                    "password": "",
                    "name": name,
                    "email": email,
                    "auth_key": "FREE-TRIAL",
                    "created": datetime.now().isoformat(),
                    "trial_start": datetime.now().isoformat(),
                    "login_type": "trial",
                }
                save_users(users)
                session["user"] = trial_username
                return redirect(url_for("dashboard"))
    return render_template("login.html", trial_error=error, show_trial=True,
                         google_enabled=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET))


@app.route("/oauth/google/start")
def google_oauth_start():
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        return redirect(url_for("login"))

    state = secrets.token_urlsafe(32)
    session["oauth_state"] = state

    scheme = request.headers.get("X-Forwarded-Proto", request.scheme)
    host = request.headers.get("X-Forwarded-Host", request.host)
    redirect_uri = f"{scheme}://{host}/oauth/google/callback"
    session["oauth_redirect_uri"] = redirect_uri

    import urllib.parse
    params = urllib.parse.urlencode({
        "client_id": GOOGLE_CLIENT_ID,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "openid email profile",
        "state": state,
        "access_type": "offline",
        "prompt": "select_account",
    })
    return redirect(f"{GOOGLE_AUTH_URL}?{params}")


@app.route("/oauth/google/callback")
def google_oauth_callback():
    error_param = request.args.get("error")
    if error_param:
        return render_template("login.html", error="Google sign-in was cancelled.",
                             google_enabled=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET))

    returned_state = request.args.get("state")
    if returned_state != session.get("oauth_state"):
        return render_template("login.html", error="Security validation failed. Please try again.",
                             google_enabled=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET))

    code = request.args.get("code")
    if not code:
        return render_template("login.html", error="No authorization code received.",
                             google_enabled=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET))

    redirect_uri = session.get("oauth_redirect_uri", "")

    try:
        token_resp = requests.post(GOOGLE_TOKEN_URL, data={
            "code": code,
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "redirect_uri": redirect_uri,
            "grant_type": "authorization_code",
        }, timeout=15)
        token_data = token_resp.json()
        access_token = token_data.get("access_token")

        if not access_token:
            return render_template("login.html", error="Failed to get access token from Google.",
                                 google_enabled=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET))

        userinfo_resp = requests.get(GOOGLE_USERINFO_URL,
                                     headers={"Authorization": f"Bearer {access_token}"},
                                     timeout=15)
        user_info = userinfo_resp.json()

        email = user_info.get("email", "")
        name = user_info.get("name", email)
        google_id = user_info.get("id", "")

        users = load_users()
        google_username = f"google_{google_id}"
        if google_username not in users:
            users[google_username] = {
                "password": "",
                "email": email,
                "name": name,
                "google_id": google_id,
                "auth_key": "GOOGLE-AUTH",
                "created": datetime.now().isoformat(),
                "login_type": "google",
            }
            save_users(users)

        session["user"] = name or email
        return redirect(url_for("dashboard"))
    except Exception:
        return render_template("login.html", error="Google login failed. Please try again.",
                             google_enabled=bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    trial_info = get_user_trial_info(session["user"])
    is_trial = trial_info is not None
    days_left = trial_info["days_left"] if trial_info else 0
    users = load_users()
    display_name = session["user"]
    user_data = users.get(session["user"], {})
    if user_data.get("name"):
        display_name = user_data["name"]
    return render_template("dashboard.html", user=display_name, version=CURRENT_VERSION,
                         is_trial=is_trial, days_left=days_left)


@app.route("/api/command", methods=["POST"])
@login_required
def run_command():
    data = request.get_json()
    cmd_key = data.get("command", "") if data else ""

    if cmd_key not in ALLOWED_COMMANDS:
        return jsonify({"error": "Blocked unrecognized command."}), 400

    trial_info = get_user_trial_info(session.get("user", ""))
    if trial_info and cmd_key not in TRIAL_ALLOWED_COMMANDS:
        return jsonify({"error": "This feature is not available in the free trial. Upgrade to full access."}), 403

    cmd_info = ALLOWED_COMMANDS[cmd_key]
    job_id = str(uuid.uuid4())

    with _jobs_lock:
        _jobs[job_id] = {
            "lines": deque(maxlen=5000),
            "done": False,
            "started": time.time(),
        }

    def worker():
        job = _jobs[job_id]
        ts = datetime.now().strftime('%H:%M:%S')
        job["lines"].append(f"\u250c{'─'*48}\u2510")
        job["lines"].append(f"\u2502 [{ts}] {cmd_info['description']}")
        job["lines"].append(f"\u2502 Command: {cmd_info['display']}")
        job["lines"].append(f"\u2514{'─'*48}\u2518")
        job["lines"].append("")
        job["lines"].append("\u25b6 NOTE: Running in Linux/Replit environment.")
        job["lines"].append("  Windows commands will be simulated here.")
        job["lines"].append("  On Windows, these execute with admin privileges.")
        job["lines"].append("")

        try:
            process = subprocess.Popen(
                cmd_info["args"],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True
            )
            for line in iter(process.stdout.readline, ''):
                job["lines"].append(f"  {line.rstrip()}")
            for line in iter(process.stderr.readline, ''):
                job["lines"].append(f"  \u26a0 {line.rstrip()}")
            process.wait()

            if process.returncode == 0:
                job["lines"].append(f"\n\u2713 {cmd_info['description']} completed successfully.\n")
            else:
                job["lines"].append(f"\n\u25b6 Command returned code {process.returncode}.")
                job["lines"].append("  On Windows, run as Administrator for full access.\n")
        except FileNotFoundError:
            first_word = cmd_info["display"].split()[0]
            job["lines"].append(f"\n\u25b6 '{first_word}' is a Windows-specific command.")
            job["lines"].append("  This will work when running on Windows.")
            job["lines"].append("  Run the application as Administrator.\n")
        except Exception as e:
            job["lines"].append(f"\n\u2717 Error: {str(e)}\n")
        finally:
            job["done"] = True

    threading.Thread(target=worker, daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/api/stream/<job_id>")
@login_required
def stream_output(job_id):
    with _jobs_lock:
        if job_id not in _jobs:
            return jsonify({"error": "Job not found"}), 404

    def generate():
        sent = 0
        while True:
            job = _jobs.get(job_id)
            if not job:
                break
            lines = list(job["lines"])
            new_lines = lines[sent:]
            for line in new_lines:
                yield f"data: {json.dumps({'line': line})}\n\n"
                sent += 1
            if job["done"] and sent >= len(lines):
                yield f"data: {json.dumps({'done': True})}\n\n"
                break
            time.sleep(0.1)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        }
    )


@app.route("/api/validate-key", methods=["POST"])
def validate_key():
    data = request.get_json()
    key = data.get("key", "").strip() if data else ""
    if key in VALID_AUTH_KEYS:
        return jsonify({"valid": True})
    return jsonify({"valid": False})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
